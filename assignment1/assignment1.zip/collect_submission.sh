rm -f assignment1.zip
zip -r assignment1.zip *.py *.ipynb
